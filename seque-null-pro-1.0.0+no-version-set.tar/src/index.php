<?php
$www = require 'header.php';
echo $www['param'];
